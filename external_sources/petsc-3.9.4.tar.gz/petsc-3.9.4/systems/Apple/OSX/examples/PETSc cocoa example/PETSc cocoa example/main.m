//
//  main.m
//  PETSc cocoa example
//
//  Created by Barry Smith on 8/2/12.
//  Copyright (c) 2012 Barry Smith. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
